package com.example.gymcross;

public interface RecyclerViewInterface {
        void onItemClick(int position);
}
